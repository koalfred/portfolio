<?php
    the_field('styles');
    ?>
    <h2 class="services-header">Gallery</h2>
    <div id="lightgallery" class="lightgallery">
<?php
$images = get_field('gallery');
if( $images ): ?>
         <ul class="gallery-link lightgallery" id="lightgallery">
            <?php foreach( $images as $image ): ?>
                <li>
                   <a href="<?php echo $image['url']; ?>" data-lightbox="mygallery"><img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>" title="<?php echo $image['caption']; ?>" /></a>
                </li>
            <?php endforeach; ?>